## Module <auto_logout_idle_user_odoo>

#### 12.01.2024
#### Version 17.0.1.0.0
##### ADD
- Initial Commit for Logout Idle User